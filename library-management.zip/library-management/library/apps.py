from django.apps import AppConfig


class LibraryConfig(AppConfig):
    DEFAULT_AUTO_FIELD = 'django.db.models.AutoField'
    name = 'library'
